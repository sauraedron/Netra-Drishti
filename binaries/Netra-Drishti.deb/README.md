Netra-Drishti
=============

A stupid Bash Script which repeats itself after 10 mins to notify you that you need to move your eyes away from your machine/laptop.
Icon is "Monkaa" character by Weybec Studio.
sudo mkdir /opt/nd
sudo mv ico.png /opt/nd
mv nd.sh /usr/local/bin

Open startup applications add the nd.sh file to startup applications and done

